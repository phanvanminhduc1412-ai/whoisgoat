// db.js
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'votes.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS votes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    player      TEXT    NOT NULL CHECK (player IN ('messi', 'ronaldo')),
    user_hash   TEXT    NOT NULL,
    ip_hash     TEXT    NOT NULL,
    created_at  INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_votes_player ON votes(player);
  CREATE INDEX IF NOT EXISTS idx_votes_time   ON votes(created_at DESC);
`);

const stmts = {
  stats: db.prepare(`SELECT player, COUNT(*) AS count FROM votes GROUP BY player`),
  insert: db.prepare(
    `INSERT INTO votes (player, user_hash, ip_hash, created_at) VALUES (?, ?, ?, ?)`
  ),
  total: db.prepare(`SELECT COUNT(*) AS c FROM votes`),
};

function getStats() {
  const rows = stmts.stats.all();
  const counts = { messi: 0, ronaldo: 0 };
  for (const r of rows) counts[r.player] = r.count;
  const total = counts.messi + counts.ronaldo;
  return {
    messi: counts.messi,
    ronaldo: counts.ronaldo,
    total,
    messiPercent: total > 0 ? (counts.messi / total) * 100 : 0,
    ronaldoPercent: total > 0 ? (counts.ronaldo / total) * 100 : 0,
    updatedAt: Date.now(),
  };
}

/**
 * Cast a vote atomically. No cooldown checks — every call inserts exactly one
 * row. The transaction ensures a single vote can't be double-inserted if two
 * requests happen to arrive together.
 */
const castVoteTx = db.transaction((player, userHash, ipHash) => {
  stmts.insert.run(player, userHash, ipHash, Date.now());
}).immediate;

module.exports = { db, getStats, castVoteTx, stmts };