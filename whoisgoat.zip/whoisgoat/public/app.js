/* Messi or Ronaldo — front-end logic
 *
 * 24h cooldown is a VISUAL-ONLY effect:
 *   • On vote success → save timestamp to localStorage → show countdown
 *   • On page load    → clear localStorage → user can vote immediately
 *   • Backend has no cooldown — every click sends a real vote.
 */
(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

  const COOLDOWN_KEY = 'messi-ronaldo-fake-cooldown';
  const FAKE_COOLDOWN_MS = 24 * 60 * 60 * 1000; // 24h — display only

  const state = {
    stats: { messi: 0, ronaldo: 0, total: 0, messiPercent: 0, ronaldoPercent: 0 },
    voting: false,
    fakeCooldown: null, // { player, startedAt, endAt }
    cooldownInterval: null,
    sse: null,
  };

  const els = {
    messiNumber: $('.player--messi .vote-number'),
    ronaldoNumber: $('.player--ronaldo .vote-number'),
    messiCooldown: $('.player--messi .cooldown'),
    ronaldoCooldown: $('.player--ronaldo .cooldown'),
    totalVotes: $('#totalVotes'),
    messiPct: $('#messiPct'),
    ronaldoPct: $('#ronaldoPct'),
    messiVotes: $('#messiVotes'),
    ronaldoVotes: $('#ronaldoVotes'),
    barMessi: $('#barMessi'),
    barRonaldo: $('#barRonaldo'),
    toastStack: $('#toastStack'),
    hearts: $$('.heart-btn'),
    year: $('#year'),
    cursorGlow: $('#cursorGlow'),
    overlay: $('#loadingOverlay'),
  };

  /* ---------------- utils ---------------- */
  const nf = new Intl.NumberFormat('en-US');
  const fmt = (n) => nf.format(n);

  function fmtClock(ms) {
    const totalSec = Math.max(0, Math.ceil(ms / 1000));
    const h = String(Math.floor(totalSec / 3600)).padStart(2, '0');
    const m = String(Math.floor((totalSec % 3600) / 60)).padStart(2, '0');
    const s = String(totalSec % 60).padStart(2, '0');
    return `${h}:${m}:${s}`;
  }

  function animateNumber(el, from, to, duration = 850) {
    if (!el) return;
    if (from === to) { el.textContent = fmt(to); return; }
    el.classList.add('bump');
    const start = performance.now();
    function tick(now) {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      el.textContent = fmt(Math.round(from + (to - from) * eased));
      if (t < 1) requestAnimationFrame(tick);
      else {
        el.textContent = fmt(to);
        setTimeout(() => el.classList.remove('bump'), 500);
      }
    }
    requestAnimationFrame(tick);
  }

  /* ---------------- render stats ---------------- */
  function renderStats(next) {
    const prev = state.stats;
    state.stats = next;

    animateNumber(els.messiNumber, prev.messi, next.messi);
    animateNumber(els.ronaldoNumber, prev.ronaldo, next.ronaldo);
    animateNumber(els.totalVotes, prev.total, next.total);

    els.messiPct.textContent = next.messiPercent.toFixed(1) + '%';
    els.ronaldoPct.textContent = next.ronaldoPercent.toFixed(1) + '%';
    els.messiVotes.textContent = `${fmt(next.messi)} votes`;
    els.ronaldoVotes.textContent = `${fmt(next.ronaldo)} votes`;

    els.barMessi.style.width = next.messiPercent + '%';
    els.barRonaldo.style.width = next.ronaldoPercent + '%';
  }

  /* ---------------- toast ---------------- */
  function toast(message, type = 'info', duration = 3200) {
    const el = document.createElement('div');
    el.className = `toast toast--${type}`;
    el.textContent = message;
    els.toastStack.appendChild(el);
    setTimeout(() => {
      el.classList.add('is-leaving');
      setTimeout(() => el.remove(), 420);
    }, duration);
  }

  /* ---------------- visual effects ---------------- */
  function spawnFloatPlus(x, y, color) {
    const el = document.createElement('div');
    el.className = 'floating-plus';
    el.textContent = '+1';
    el.style.left = `${x}px`;
    el.style.top = `${y}px`;
    el.style.color = color;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1300);
  }

  function spawnParticles(x, y, color) {
    const count = 14;
    for (let i = 0; i < count; i++) {
      const p = document.createElement('div');
      p.className = 'particle';
      p.style.background = color;
      p.style.boxShadow = `0 0 10px ${color}`;
      p.style.left = `${x}px`;
      p.style.top = `${y}px`;
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.5;
      const dist = 40 + Math.random() * 70;
      const dx = Math.cos(angle) * dist;
      const dy = Math.sin(angle) * dist;
      p.animate(
        [
          { transform: 'translate(-50%, -50%) scale(1)', opacity: 1 },
          { transform: `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px)) scale(0)`, opacity: 0 },
        ],
        { duration: 700 + Math.random() * 400, easing: 'cubic-bezier(0.16, 1, 0.3, 1)' }
      ).onfinish = () => p.remove();
      document.body.appendChild(p);
    }
  }

  function ripple(btn) {
    const r = document.createElement('span');
    r.className = 'heart-ripple';
    r.style.left = '50%';
    r.style.top = '50%';
    btn.appendChild(r);
    setTimeout(() => r.remove(), 800);
  }

  /* ---------------- fake cooldown (visual only) ---------------- */
  function startFakeCooldown(player) {
    const startedAt = Date.now();
    const endAt = startedAt + FAKE_COOLDOWN_MS;
    state.fakeCooldown = { player, startedAt, endAt };

    // Persist for the current session only — cleared on next page load.
    try {
      localStorage.setItem(COOLDOWN_KEY, JSON.stringify(state.fakeCooldown));
    } catch { /* private mode etc. */ }

    els.hearts.forEach((h) => {
      h.classList.add('is-voted');
      h.setAttribute('aria-disabled', 'true');
    });

    updateCooldownText();

    if (state.cooldownInterval) clearInterval(state.cooldownInterval);
    state.cooldownInterval = setInterval(updateCooldownText, 1000);
  }

  function updateCooldownText() {
    if (!state.fakeCooldown) return;
    const remaining = state.fakeCooldown.endAt - Date.now();
    if (remaining <= 0) {
      endFakeCooldown();
      return;
    }
    const text = `NEXT VOTE AVAILABLE IN ${fmtClock(remaining)}`;
    [els.messiCooldown, els.ronaldoCooldown].forEach((el) => {
      if (!el) return;
      el.textContent = text;
      el.classList.add('is-voted');
    });
  }

  function endFakeCooldown() {
    state.fakeCooldown = null;
    if (state.cooldownInterval) clearInterval(state.cooldownInterval);
    try { localStorage.removeItem(COOLDOWN_KEY); } catch {}
    els.hearts.forEach((h) => {
      h.classList.remove('is-voted');
      h.setAttribute('aria-disabled', 'false');
    });
    [els.messiCooldown, els.ronaldoCooldown].forEach((el) => {
      if (!el) return;
      el.textContent = 'VOTE NOW';
      el.classList.remove('is-voted');
    });
  }

  /* ---------------- network ---------------- */
  async function loadStats() {
    try {
      const r = await fetch('/api/stats', { cache: 'no-store' });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      renderStats(await r.json());
      return true;
    } catch (err) {
      console.warn('[stats] failed:', err);
      return false;
    }
  }

  async function castVote(player, btn) {
    // Fake cooldown → silently ignore (no error, no toast)
    if (state.fakeCooldown) {
      btn.classList.add('wobble');
      setTimeout(() => btn.classList.remove('wobble'), 450);
      return;
    }
    if (state.voting) return;

    state.voting = true;
    const rect = btn.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const color = player === 'messi' ? '#3b82f6' : '#ef4444';
    const heartColor = player === 'messi' ? '#67e8f9' : '#fca5a5';

    btn.classList.add('is-popping');
    ripple(btn);
    spawnFloatPlus(cx, cy, heartColor);
    spawnParticles(cx, cy, color);
    setTimeout(() => btn.classList.remove('is-popping'), 650);

    try {
      const r = await fetch('/api/vote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ player }),
      });
      const data = await r.json().catch(() => ({}));

      if (!r.ok) {
        toast(data.error || 'Could not cast vote.', 'error');
        return;
      }

      if (data.stats) renderStats(data.stats);
      toast(`Voted for ${player === 'messi' ? 'Messi' : 'Ronaldo'} 🔥`, 'success');
      startFakeCooldown(player);
    } catch (err) {
      console.error('[vote] error:', err);
      toast('Connection error. Please try again.', 'error');
    } finally {
      state.voting = false;
    }
  }

  /* ---------------- SSE ---------------- */
  function connectSSE() {
    if (state.sse) state.sse.close();
    const es = new EventSource('/api/stream');
    state.sse = es;
    es.onmessage = (ev) => {
      try {
        const data = JSON.parse(ev.data);
        if (data && data.total !== state.stats.total) renderStats(data);
      } catch { /* ignore */ }
    };
    es.onerror = () => { /* auto-reconnect */ };
  }

  /* ---------------- boot ---------------- */
  async function init() {
    if (els.year) els.year.textContent = new Date().getFullYear();

    // ⚠️ Refresh = reset fake cooldown → user can vote immediately.
    try { localStorage.removeItem(COOLDOWN_KEY); } catch {}

    // Default cooldown label
    [els.messiCooldown, els.ronaldoCooldown].forEach((el) => {
      if (el) el.textContent = 'VOTE NOW';
    });

    if (els.cursorGlow && matchMedia('(hover: hover)').matches) {
      document.addEventListener(
        'mousemove',
        (e) => {
          els.cursorGlow.style.setProperty('--mx', `${e.clientX}px`);
          els.cursorGlow.style.setProperty('--my', `${e.clientY}px`);
        },
        { passive: true }
      );
    }

    els.hearts.forEach((btn) => {
      btn.addEventListener('click', () => {
        const player = btn.dataset.player;
        if (player === 'messi' || player === 'ronaldo') castVote(player, btn);
      });
    });

    const ok = await loadStats();

    if (els.overlay) {
      els.overlay.classList.add('is-hidden');
      setTimeout(() => els.overlay.remove(), 650);
    }

    if (ok) connectSSE();
    else {
      toast('Could not reach the server. Retrying…', 'error');
      setTimeout(init, 2500);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();