# ⚽ Messi or Ronaldo — Who is the GOAT?

A premium, realtime, server-verified voting site. Every vote is stored in a
SQLite database; the 24-hour cooldown is enforced server-side.

## Stack
- **Backend:** Node.js · Express · better-sqlite3
- **Realtime:** Server-Sent Events (SSE)
- **Frontend:** Vanilla HTML/CSS/JS — no build step

## Quick start
```bash
npm install
npm start
# → http://localhost:3000