// server.js
const express = require('express');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const { getStats, castVoteTx } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const SALT = process.env.VOTE_SALT || 'change-me-in-production-please';
const MAX_SSE_CLIENTS = 2000;

app.set('trust proxy', true);
app.use(express.json({ limit: '8kb' }));

// ---------- static assets ----------
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

for (const name of ['image1.png', 'image2.png']) {
  app.get(`/${name}`, (req, res, next) => {
    const p = path.join(__dirname, name);
    if (fs.existsSync(p)) return res.sendFile(p);
    next();
  });
}

// ---------- helpers ----------
function clientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  return (fwd ? fwd.split(',')[0] : req.socket.remoteAddress || '').trim();
}
function userHashOf(req) {
  const ua = req.headers['user-agent'] || '';
  return crypto.createHash('sha256').update(`${clientIp(req)}|${ua}|${SALT}`).digest('hex');
}
function ipHashOf(req) {
  return crypto.createHash('sha256').update(`${clientIp(req)}|${SALT}`).digest('hex');
}

// ---------- very generous per-IP rate limit ----------
// 100 requests / 10 s — well above any human clicking rate, only stops
// obvious bot floods. Not related to voting cooldown at all.
const rateMap = new Map();
const RL_WINDOW = 10_000;
const RL_MAX = 100;
function rateLimit(req, res, next) {
  const ip = clientIp(req);
  const now = Date.now();
  const arr = (rateMap.get(ip) || []).filter((t) => now - t < RL_WINDOW);
  if (arr.length >= RL_MAX) {
    return res.status(429).json({ error: 'Too many requests. Slow down.' });
  }
  arr.push(now);
  rateMap.set(ip, arr);
  next();
}

// ---------- SSE ----------
const sseClients = new Set();

function broadcast() {
  if (!sseClients.size) return;
  const payload = `data: ${JSON.stringify(getStats())}\n\n`;
  for (const res of sseClients) {
    try { res.write(payload); } catch { sseClients.delete(res); }
  }
}

setInterval(() => {
  for (const res of sseClients) {
    try { res.write(': ping\n\n'); } catch { sseClients.delete(res); }
  }
}, 25_000).unref();

// ---------- API ----------
app.get('/api/stats', (_req, res) => res.json(getStats()));

/**
 * POST /api/vote
 * No cooldown. Every valid request inserts exactly one vote.
 * The frontend's 24h timer is cosmetic only.
 */
app.post('/api/vote', rateLimit, (req, res) => {
  const { player } = req.body || {};
  if (player !== 'messi' && player !== 'ronaldo') {
    return res.status(400).json({ error: 'Invalid player.' });
  }
  try {
    castVoteTx(player, userHashOf(req), ipHashOf(req));
    const stats = getStats();
    broadcast();
    return res.json({ ok: true, player, stats });
  } catch (err) {
    console.error('[vote] error:', err);
    return res.status(500).json({ error: 'Server error while saving vote.' });
  }
});

app.get('/api/stream', (req, res) => {
  if (sseClients.size >= MAX_SSE_CLIENTS) return res.status(503).end();
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();
  res.write(`retry: 3000\n\n`);
  res.write(`data: ${JSON.stringify(getStats())}\n\n`);
  sseClients.add(res);
  req.on('close', () => sseClients.delete(res));
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    for (const r of sseClients) try { r.end(); } catch {}
    process.exit(0);
  });
}

app.listen(PORT, () => {
  console.log(`⚽  Messi-or-Ronaldo server running:  http://localhost:${PORT}`);
});